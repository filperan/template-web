package elenziasabari_222035_Latihan2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class elenWhileIF1 {
    public static void main (String args[]) {
        char input = (char) -1;
        int numToCount;
        System.out.println("Masukkan satu angka antara 1 dan 10: ");
        try {
            input = (char) System.in.read();
        }
        catch (Exception e) {
            System.out.println("Error : " + e.toString());
        }
        numToCount = Character.digit(input, 10);
        if ((numToCount > 0) && (numToCount < 10)) {
            int i = 1;
            while (i <= numToCount) {
                System.out.println(i);
                i++;
            }
        }
        else System.out.println("Angka tsb tidak berada diantara 1 dan 10");
    }

}
