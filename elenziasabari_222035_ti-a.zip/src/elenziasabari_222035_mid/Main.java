package elenziasabari_222035_mid;

import java.util.ArrayList;
import java.util.Scanner;

class Menu {
    String name;
    double price;
    String category;

    Menu(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }
}

class OrderedItem {
    Menu menu;
    int quantity;

    OrderedItem(Menu menu, int quantity) {
        this.menu = menu;
        this.quantity = quantity;
    }

    double getTotalPrice() {
        return menu.price * quantity;
    }
}

public class Main {
    private static ArrayList<Menu> menuItems = new ArrayList<>();
    private static ArrayList<OrderedItem> orderedItems = new ArrayList<>();

    public static void main(String[] args) {
        initializeMenu();

        displayMenu();

        takeOrders();

        double totalCost = calculateTotalCost();
        double tax = calculateTax(totalCost);
        double serviceCharge = 20000;

        applyDiscountAndOffer(totalCost);

        printReceipt(totalCost, tax, serviceCharge);
    }

    private static void initializeMenu() {
        menuItems.add(new Menu("Nasi Goreng", 25000, "Makanan"));
        menuItems.add(new Menu("Soto Ayam", 30000, "Makanan"));
        menuItems.add(new Menu("Es Teh", 5000, "Minuman"));
        menuItems.add(new Menu("Jus Alpukat", 15000, "Minuman"));
        // Tambahkan menu restoran lainnya sesuai kebutuhan
    }

    private static void displayMenu() {
        System.out.println("Menu Restoran:");
        for (int i = 0; i < menuItems.size(); i++) {
            Menu menuItem = menuItems.get(i);
            System.out.println((i + 1) + ". " + menuItem.name + " - " + menuItem.price);
        }
    }

    private static void takeOrders() {
        Scanner scanner = new Scanner(System.in);
        String userInput;
        do {
            System.out.print("Pilih menu (selesai untuk menyelesaikan pemesanan): ");
            userInput = scanner.nextLine();

            if (!userInput.equalsIgnoreCase("selesai")) {
                try {
                    int selectedMenuIndex = Integer.parseInt(userInput) - 1;
                    if (selectedMenuIndex >= 0 && selectedMenuIndex < menuItems.size()) {
                        System.out.print("Jumlah pesanan: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        orderedItems.add(new OrderedItem(menuItems.get(selectedMenuIndex), quantity));
                    } else {
                        System.out.println("Menu tidak valid. Silakan pilih lagi.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Input tidak valid. Silakan pilih lagi.");
                }
            }
        } while (!userInput.equalsIgnoreCase("selesai"));

        scanner.close();
    }

    private static double calculateTotalCost() {
        double totalCost = 0;
        for (OrderedItem orderedItem : orderedItems) {
            totalCost += orderedItem.getTotalPrice();
        }
        return totalCost;
    }

    private static double calculateTax(double totalCost) {
        return 0.1 * totalCost;
    }

    private static void applyDiscountAndOffer(double totalCost) {
        if (totalCost > 100000) {
            totalCost *= 0.9; // Diskon 10%
        }
        if (totalCost > 50000) {
            // Penawaran beli satu gratis satu untuk minuman
            for (OrderedItem orderedItem : orderedItems) {
                if (orderedItem.menu.category.equalsIgnoreCase("Minuman")) {
                    totalCost -= orderedItem.menu.price;
                    break;
                }
            }
        }
    }

    private static void printReceipt(double totalCost, double tax, double serviceCharge) {
        System.out.println("\nStruk Pesanan:");
        for (OrderedItem orderedItem : orderedItems) {
            System.out.println(orderedItem.menu.name + " - " + orderedItem.menu.price +
                    " x " + orderedItem.quantity + " = " + orderedItem.getTotalPrice());
        }
        if (totalCost > 100000) {
            totalCost *= 0.9; // Diskon 10%
            System.out.println("\nTotal Biaya: " + totalCost);
            System.out.println("Pajak (10%): " + tax);
            System.out.println("Biaya Pelayanan: " + serviceCharge);
            System.out.println("Total Pembayaran: " + (totalCost + serviceCharge + tax));
        }
        else if (totalCost > 50000) {
            // Penawaran beli satu gratis satu untuk minuman
            for (OrderedItem orderedItem : orderedItems) {
                if (orderedItem.menu.category.equalsIgnoreCase("Minuman")) {
                    totalCost -= orderedItem.menu.price;
                    System.out.println("\nTotal Biaya: " + totalCost);
                    System.out.println("Pajak (10%): " + tax);
                    System.out.println("Biaya Pelayanan: " + serviceCharge);
                    System.out.println("Total Pembayaran: " + (totalCost + serviceCharge + tax));
                    System.out.println("Gratis 1 Minuman");
                    break;
                }
            }
        } else {
                    System.out.println("\nTotal Biaya: " + totalCost);
                    System.out.println("Pajak (10%): " + tax);
                    System.out.println("Biaya Pelayanan: " + serviceCharge);
                    System.out.println("Total Pembayaran: " + (totalCost + serviceCharge + tax));
        }
    }
}
