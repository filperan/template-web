package elenziasabari_222035_Latihan9;

public class Codeternity {
    public static void main(String[] args) {
        Horse horse = new Horse();
        horse.accelerate();
        horse.turnLeft();
        horse.turnRight();
        horse.eat();
    }
}

interface Drivable {
    void accelerate();
    void turnLeft();
    void turnRight();
}

class Animal {
    public void eat() {
        System.out.println("Hm... eating");
    }
}

class Horse extends Animal implements Drivable {

    @Override
    public void accelerate() {
        System.out.println("Horse is accelerating");
    }

    @Override
    public void turnLeft() {
        System.out.println("Horse is turning Left");
    }

    @Override
    public void turnRight() {
        System.out.println("Horse is turning right");
    }
}
