package elenziasabari_222035_Latihan9;

public class Latihan9_6 {
    public static void main(String[] args) {
        Car car = new Car();
        car.accelerate();
        car.turnLeft();
        car.turnRight();
        
    }
    
}
interface Drivable{
    void accelerate();
    void turnLeft();
    void turnRight();
}
class Car implements Drivable{
    @Override
    public void accelerate(){
        System.out.println("Car is accelerate");
    }
    @Override
    public void turnLeft(){
        System.out.println("Car is turn left");
    }
    @Override
    public void turnRight(){
        System.out.println("Car  is turn right");
    }
}