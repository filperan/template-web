package elenziasabari_222035_Latihan9;

abstract class Hewan {
    protected String nama;
    protected int jumKaki;
    protected boolean bisaTerbang = false;
    public Hewan(String nama,int kaki, boolean terbang){
        this.nama=nama;
        jumKaki = kaki;
        bisaTerbang = terbang;
    }
    public abstract void bersuara();
    
    public void lihatHewan(){
        System.out.println("");
        System.out.println("nama :"+ nama);
        System.out.println("jumlah kaki :"+ jumKaki);
        System.out.println("bisa terbang :"+ bisaTerbang);
    }
}
class Sapi extends Hewan{
public Sapi(){
    super("sapi", 4, false);
}    
@Override
    public void bersuara(){
        System.out.println("\nmoooaahhhhh,moooaahhhh");
    }
    public static void main(String[] args) {
        Sapi s = new Sapi();
        s.lihatHewan();
        s.bersuara();
    }
}
class Perkutut extends Hewan{
    public Perkutut(){
    super("Perkutut", 2, true);
}    
@Override
    public void bersuara(){
        System.out.println("\ncuit,cuit,cuit");
    }
    public static void main(String[] args) {
        Perkutut p = new Perkutut();
        p.lihatHewan();
        p.bersuara();
    }
}