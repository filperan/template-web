package elenziasabari_222035_Latihan9;

public class Latihan9_5 {
        public static void main(String[] args) {
        long longNumber = 20;
        int intNumber = (int)longNumber;
        System.out.println(longNumber);        
        System.out.println(intNumber);

               
    }
    
}
