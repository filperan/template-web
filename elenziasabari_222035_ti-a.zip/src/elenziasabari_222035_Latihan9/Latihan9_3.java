package elenziasabari_222035_Latihan9;

public class Latihan9_3 {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        Car car = new Car();
        
        vehicle.info();
        car.info();
    }
}

class Vehicle {
    public void run() {
        System.out.println("This is a vehicle");
    }
    
    public void info() {
        System.out.println("Vehicle information");
    }
}

class Car extends Vehicle {
    public void info() {
        System.out.println("This is a car");
    }
}
