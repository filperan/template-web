package elenziasabari_222035_Latihan9;

public class Latihan9_2 {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        vehicle.run();
        vehicle.run(100);
        vehicle.run("fast");
    }
}

class Vehicle {
    public void run() {
        System.out.println("Vehicle is running");
    }
    
    public void run(int speed) {
        System.out.println("Vehicle is running at " + speed + " km/h");
    }
    
    public void run(String speed) {
        System.out.println("Vehicle is running " + speed);
    }
}
