package elenziasabari_222035_Latihan9;

public class Latihan9_4 {
    public static void main(String[] args) {
        int intNumber = 10;
        long longNumber = intNumber;
        System.out.println(intNumber);
        System.out.println(longNumber);
               
    }
    
}
