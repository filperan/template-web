/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan3;

import java.io.DataInputStream;

public class Latihan3_ProgLoop {
    public static void main(String[] args) {
        int N=0;
        int idx=0;
        String input=" ";
        DataInputStream in = new DataInputStream(System.in);
        try {
            System.out.print("Masukkan jumlah anak ayam: ");
            input = in.readLine();
            N = Integer.parseInt(input);
        }
    catch (Exception e) {}
    idx = N;
    while (idx > 1)
    {
        System.out.println("Kotek-kotek kotek ...");
        System.out.println("Anak ayam berkotek");
    System.out.println("Anak ayam turun " + idx);
    idx--;
    System.out.println("mati 1 tinggal " + idx);
    System.out.println(" ");
    }
    System.out.println("Anak ayam turun " + idx);
    System.out.println("mati 1 tinggal induknya");
    }
}  

