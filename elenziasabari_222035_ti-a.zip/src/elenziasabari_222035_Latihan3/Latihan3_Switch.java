/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan3;

/**
 *
 * @author ASUS
 */
public class Latihan3_Switch {
     public static void main (String args[]) {
        char HurufDepan = (char) -1;
        System.out.println("Masukkan huruf depan nama anda: ");
        try {
            HurufDepan = (char) System.in.read();
        }
        catch (Exception e) {
                System.out.println("Error : " + e.toString());
        }
      switch(HurufDepan) {
      case (char) -1 : System.out.println("bukan huruf depan!"); break;
      case 'a' : System.out.println("Apa namamu Amin?"); break;
      case 'b' : System.out.println("Apa namamu Bambang?"); break;
      case 'c' : System.out.println("Apa namamu Charlie?"); break;
      case 'd' : System.out.println("Apa namamu Daud?"); break;
      case 'e' : System.out.println("Apa namamu Endang?"); break;
      default: System.out.println("Aku belum bisa menebak namamu"); 
        }
    }
}

