/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan3;

/**
 *
 * @author ASUS
 */
public class Latihan3_DoWhile {
    public static void main(String args[]){
        int i=1;
        do {
        System.out.println("STMIK ke- " +i);
        i++;
        }
        while(i<=5);{
    
        }
    }

}
