/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan3;

/**
 *
 * @author ASUS
 */
public class Latihan3_For {
    public static void main(String args[]){
        int hitung = 1;
        for(int i = 0; i < 9; i++){
            for(int j = 0; j < i + 1; j++){
                System.out.print(j);
            }
            hitung++;
            System.out.println();
        }
    }
}
