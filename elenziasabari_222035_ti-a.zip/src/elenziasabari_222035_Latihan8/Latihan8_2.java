package elenziasabari_222035_Latihan8;

import java.util.Scanner;

class Barang {
    String nama;
    float harga, jumlah;
    static float bayar, total;

    public void entry() {
        Scanner masukkan = new Scanner(System.in);
        System.out.print("masukkan nama : ");
        nama = masukkan.nextLine();
        System.out.print("masukkan jumlah : ");
        jumlah = masukkan.nextFloat();
        System.out.print("masukkan harga : ");
        harga = masukkan.nextFloat();
    }

    void proses() {
        bayar = harga * jumlah;
        total = total + bayar;
    }

    void tampil() {
        System.out.println("Nama barang: " + nama);
        System.out.println("Total bayar: " + bayar);
    }

    public static void main(String[] args) {
        Barang barang1 = new Barang();
        barang1.entry();
        barang1.proses();
        barang1.tampil();
    }
}
