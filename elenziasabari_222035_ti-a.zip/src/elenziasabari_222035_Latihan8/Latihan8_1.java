package elenziasabari_222035_Latihan8;

import java.util.Scanner;

class A {
    int a1;
    protected int a2;

    public void entrya1() {
        Scanner masukkan = new Scanner(System.in);
        System.out.print("masukkan a1 :");
        a1 = masukkan.nextInt();
    }

    public void entrya2() {
        Scanner masukkan = new Scanner(System.in);
        System.out.print("masukkan a2 :");
        a2 = masukkan.nextInt();
    }
}

class B extends A {
    int b1;

    public void entryb() {
        Scanner masukkan = new Scanner(System.in);
        System.out.print("masukkan b1 :");
        b1 = masukkan.nextInt();
        System.out.print("nilai a2 = " + a2);
    }
}

class C extends A {
    int c1;

    public void entryc() {
        Scanner masukkan = new Scanner(System.in);
        System.out.print("masukkan c1 :");
        c1 = masukkan.nextInt();
        System.out.print("nilai a2 = " + a2);
    }

    public static void main(String[] args) {
        B joni = new B();
        C tuti = new C();
        joni.entryb();
        joni.entrya1();
        joni.entrya2();
        tuti.entryc();
    }
}
