package elenziasabari_222035_Latihan6;

public class A{
    int x,y;
    
    void tampilXY(){
        System.out.println("Nilai x = "+ x + ", y ="+y);
    }
}
