package elenziasabari_222035_Latihan6;

public class B extends A{
    int z;


    void jumlah() {
        System.out.println("Jumlah :" + (x+y+z));
    }

}
