package elenziasabari_222035_Latihan6;

import elenziasabari_222035_Latihan5.GolonganUmur;
import elenziasabari_222035_Latihan5.PenghitunganUmur;
import java.io.*;

public class TurunanGolUmur extends GolonganUmur {
    static String cekGolongan(int umur) {
        String gol = "";
        if (umur < 17)
            gol = "Anak-anak";
        else if (umur < 25)
            gol = "Remaja";
        else if (umur < 40)
            gol = "Dewasa";
        else
            gol = "Manula";
        return gol;
    }

   public static void main(String[] args) {
        DataInputStream baca = new DataInputStream(System.in);
        int tahunLahir = 0;

        try {
            System.out.print("Input tahun kelahiran anda: "); // Ask for the birth year.
            tahunLahir = Integer.parseInt(baca.readLine());
        } catch (IOException e) {
            System.out.println("Input Gagal!!!!");
        }

        PenghitunganUmur umurku = new PenghitunganUmur(tahunLahir);
        System.out.println(cekGolongan(umurku.umur));
    }
}
