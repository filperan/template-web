package elenziasabari_222035_Latihan6;

public class DemoPewarisan {

    public static void main(String[] args) {
        A superObj = new A();
        B subObj = new B();
        
        System.out.println("Super class");
        superObj.x = 10;
        superObj.y = 20;
        superObj.tampilXY(); 
        
        System.out.println("Sub Class");
        subObj.x = 5;
        subObj.y = 4;
        subObj.tampilXY();
        
        subObj.z = 100;
        subObj.jumlah();
    }
    
}

