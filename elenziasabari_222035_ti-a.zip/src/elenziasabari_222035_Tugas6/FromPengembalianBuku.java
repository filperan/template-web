/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package elenziasabari_222035_Tugas6;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author user
 */
public class FromPengembalianBuku extends javax.swing.JFrame {

        Koneksi Konek = new Koneksi();
        private Connection Con;
        Statement Stm;
        ResultSet Rs;
        String Sql; 
        DefaultTableModel Dtm;
        
    public FromPengembalianBuku() {
        initComponents();
        LoadDataNomor();
        LoadDataBuku();
        TampilPengembalian();
        KosongkanObjek();
        
        
    }
public void delay() {
    LocalDate tanggal_peminjaman = jDateChooser1.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    LocalDate tanggal_pengembalian = jDateChooser2.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

    long delay = ChronoUnit.DAYS.between(tanggal_peminjaman, tanggal_pengembalian);

    jTextField3.setText(String.valueOf(delay));
    
    long denda ;
    if (delay > 7){
        denda = (delay - 7) * 50000;
    }else{
        denda = 0;
    }
    
    jTextField4.setText(String.valueOf(denda));
}




     private void LoadDataNomor(){
    String kd="";
        try{
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement();
        Sql = "select DISTINCT nomor_anggota FROM peminjaman_buku where tanggal_pengembalian is null";
        Rs=Stm.executeQuery(Sql);
            while(Rs.next()) {
            jComboBox1.addItem(Rs.getString("nomor_anggota"));
                }
            } catch(SQLException e){
            System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
    private void LoadDataBuku() {
    String kd = "";
    try {
        Con = Konek.getKoneksiDatabase();
        Stm = Con.createStatement();
        
        Sql = "SELECT kode_buku FROM peminjaman_buku WHERE tanggal_pengembalian IS NULL AND nomor_anggota = '" + "211069" + "'";
        Rs = Stm.executeQuery(Sql);
        while (Rs.next()) {
            jComboBox2.addItem(Rs.getString("kode_buku"));
        }
    } catch (SQLException e) {
        System.out.println("Koneksi Gagal" + e.toString());
    }
}


    
    //        versi baru
    private void AturJTable(JTable Lihat, int Lebar[]) {
        try {
            Lihat.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            int banyak = Lihat.getColumnCount();
            for (int i = 0; i < banyak; i++) {
                if (i < Lebar.length) { // Check array bounds
                    TableColumn Kolom = Lihat.getColumnModel().getColumn(i);
                    Kolom.setPreferredWidth(Lebar[i]);
                }
            }
            Lihat.setRowHeight(20);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "salah" + e);
        }
    }
    private void TampilModelJTabel(){
        try {
            String[]kolom={"Nomor Anggota", "kode buku", "Tanggal Pinjam", "tanggal pengembalian",  "denda"};
            Dtm = new DefaultTableModel(null, kolom){
            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false;
            }
        };
        jTable2.setModel(Dtm);
        AturJTable(jTable2, new int 
       []{100,70, 150,150,100,100} );
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "salah"+e);
        }
    }
    
    void TampilPengembalian() {
        try {
            Con = Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            TampilModelJTabel();
            try {
                Sql = "SELECT peminjaman_buku.nomor_anggota AS nomor, peminjaman_buku.kode_buku AS kode, peminjaman_buku.tanggal_peminjaman AS tglPeminjaman, peminjaman_buku.tanggal_pengembalian, peminjaman_buku.denda " +
                        "FROM peminjaman_buku " +
                        "LEFT JOIN buku ON peminjaman_buku.kode_buku = buku.kode where peminjaman_buku.tanggal_pengembalian is not null ";

                Rs = Stm.executeQuery(Sql);
                while (Rs.next()) {
                        Dtm.addRow(new Object[]{
                            Rs.getString("nomor"),
                            Rs.getString("kode"),
                            Rs.getString("tglPeminjaman"),
                            Rs.getString("tanggal_pengembalian"),
                            Rs.getString("denda"),
                        });
                    
                }

                jTable2.setModel(Dtm);
            } catch (Exception e) {
                System.out.println("Ada Kesalahan " + e.toString());
            }
        } catch (SQLException e) {
            System.out.println("koneksi gagal " + e.toString());
        }
    }

    void CariData(){
    try {
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement(); 
        TampilModelJTabel();
            try{
            Sql = "SELECT peminjaman_buku.nomor_anggota, peminjaman_buku.kode_buku AS buku, peminjaman_buku.tanggal_peminjaman, peminjaman_buku.tanggal_pengembalian," +
                    "FROM peminjaman_buku " +
                    "WHERE peminjaman_buku." + jComboBox3.getSelectedItem() + " LIKE '%" + jTextField4.getText() + "%'";

                System.out.println(jComboBox3.getSelectedItem());
            Rs = Stm.executeQuery(Sql);
            
            while(Rs.next()){
            Dtm.addRow(new Object[]{
            Rs.getString("nomor_anggota"),
            Rs.getString("buku"),
            Rs.getString("tanggal_peminjaman"),
            Rs.getString("tanggal_pengembalian"),
                });
                jTable2.setModel(Dtm);
               }
                }catch(Exception e){
                System.out.println("Ada Kesalahan " + e.toString());
                }
            }catch (SQLException e){
            System.out.println("koneksi gagal " + e.toString());
            }
    }
    void KosongkanObjek(){
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
         jTextField5.setText("");
        jComboBox1.getItemAt(0);
        jComboBox2.getItemAt(0);
        jDateChooser1.setDate(null);
        jTextField1.requestFocus();
       }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jTextField1 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jTextField5 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nomor Anggota");

        jLabel2.setText("Kode Buku");

        jLabel3.setText("Tanggal Pinjam");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextField1.setText("jTextField1");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jTextField2.setText("jTextField1");

        jLabel4.setText("Keterlambatan");

        jTextField3.setText("jTextField1");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jDateChooser2.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jDateChooser2PropertyChange(evt);
            }
        });

        jLabel6.setText("Tanggal Kembali");

        jLabel7.setText("Hari");

        jLabel8.setText("Denda");

        jTextField4.setText("jTextField1");
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(31, 31, 31)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField4))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel8)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(154, 154, 154))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jComboBox1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jComboBox2)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(189, 189, 189))))
        );

        jButton1.setText("Simpan");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Batal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Exit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel5.setText("Cari");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]", "kode_buku", "tanggal_peminjaman", "tanggal_pengembalian" }));

        jTextField5.setText("jTextField4");

        jButton6.setText("Cari");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Refresh");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6)
                    .addComponent(jButton7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jDateChooser2PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jDateChooser2PropertyChange
        // TODO add your handling code here:
        if ("date".equals(evt.getPropertyName())) {
            delay();
        }
    }//GEN-LAST:event_jDateChooser2PropertyChange

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:                                        
    String Tampilan = "yyyy-MM-dd";
    SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
    String tanggal_peminjaman = Fm.format(jDateChooser1.getDate());
    String tanggal_pengembalian = Fm.format(jDateChooser2.getDate());
    String kodeBuku = jComboBox2.getSelectedItem().toString();
    String denda = jTextField4.getText();

    try {
        Con = Konek.getKoneksiDatabase();
        Stm = Con.createStatement();

        // Update peminjaman_buku table
        Sql = "UPDATE peminjaman_buku SET nomor_anggota ='" + jComboBox1.getSelectedItem().toString() + "' , kode_buku = '" + kodeBuku + "', tanggal_peminjaman = '" + tanggal_peminjaman + "', tanggal_pengembalian = '" + tanggal_pengembalian+ "', denda = '" + denda + "', last_update = NOW(), userid = 'ADMIN' WHERE nomor_anggota = '" + jComboBox1.getSelectedItem().toString() + "'";

        int result = Stm.executeUpdate(Sql);
        if (result > 0) {
            // Mengurangi stok buku
            Sql = "UPDATE buku SET stock = stock + 1 WHERE kode = '" + kodeBuku + "'";
            Stm.executeUpdate(Sql);
            JOptionPane.showMessageDialog(this, "Data Berhasil Tersimpan", "Informasi", JOptionPane.INFORMATION_MESSAGE);
            TampilPengembalian();
            KosongkanObjek();
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
        } else {
            JOptionPane.showMessageDialog(this, "Data Gagal Tersimpan", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        }

        Stm.close();
    } catch (SQLException e) {
        System.out.println("Koneksi Gagal " + e.toString());
    }



    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
                // TODO add your handling code here:
        
                 String Tampilan="yyyy-MM-dd";
        SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
        String tanggal_peminjaman = String.valueOf(Fm.format(jDateChooser1.getDate()));
        String tanggal_pengembalian = String.valueOf(Fm.format(jDateChooser2.getDate()));
        String nomorAnggota = jComboBox1.getSelectedItem().toString();
        String kodeBuku = jComboBox2.getSelectedItem().toString();
        String denda = jTextField4.getText();

        try {
       Con = Konek.getKoneksiDatabase();
        Stm = null; 
        Sql = "UPDATE peminjaman_buku SET (nomor_anggota, kode_buku, tanggal_peminjaman, tanggal_pengembalian, denda, last_update, userid) " +
                "VALUES ('" + nomorAnggota + "', '" + kodeBuku + "', '" + tanggal_peminjaman + "', '" + tanggal_pengembalian + "','" + denda + "', NOW(), 'ADMIN')";

        Stm= Con.createStatement();
        int AdaPerubahanRecord= Stm.executeUpdate(Sql);
        TampilPengembalian();
        if (AdaPerubahanRecord>0){
        JOptionPane.showMessageDialog(this,"Data Berhasil Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        jButton1.setEnabled(true);
        }else
        JOptionPane.showMessageDialog(this,"Data Gagal Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        Stm.close();
        
        KosongkanObjek();
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);

        } catch (SQLException e){
        System.out.println("Koneksi Gagal " +e.toString());
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try {
    Con = Konek.getKoneksiDatabase();
    Stm = Con.createStatement();
    String nomorAnggota = jComboBox1.getSelectedItem().toString();

    // Ambil kode buku yang sedang dipinjam oleh anggota tersebut
    String kodeBuku = jComboBox2.getSelectedItem().toString();

    // Periksa apakah buku tersebut sedang dipinjam oleh anggota yang akan dihapus datanya
    Sql = "SELECT * FROM peminjaman_buku WHERE nomor_anggota='" + nomorAnggota + "' AND kode_buku='" + kodeBuku + "'";
    Rs = Stm.executeQuery(Sql);
    if (Rs.next()) {
//         Lakukan delete
        Sql = "DELETE FROM peminjaman_buku WHERE nomor_anggota = '" + nomorAnggota + "'";
        int adaPerubahanRecord = Stm.executeUpdate(Sql);
        if (adaPerubahanRecord > 0) {
            // Tambahkan stok buku
            Stm.executeUpdate(Sql);

            JOptionPane.showMessageDialog(this, "Data Berhasil Di Hapus", "Informasi", JOptionPane.INFORMATION_MESSAGE);
            TampilPengembalian();
            jButton1.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(this, "Data Gagal Di Hapus", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Data peminjaman buku tidak ditemukan.", "Informasi", JOptionPane.INFORMATION_MESSAGE);
    }
    Stm.close();

        KosongkanObjek();
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
    } catch (SQLException e) {
        System.out.println("Koneksi Gagal " + e.toString());
    }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
              KosongkanObjek();
        jButton1.setEnabled(true);
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
              this.dispose();

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        CariData();
        KosongkanObjek();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        TampilPengembalian();
        KosongkanObjek();        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
            String Kode="";
            try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from biodata_mahasiswa where nim='" 
           +jComboBox1.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField1.setText(Kode);
                } catch(SQLException e){
            System.out.println("koneksi gagal"+e.toString()); 
                }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed

    String Kode = "";
    Date tanggalPeminjaman = null;
    try {
        Con = Konek.getKoneksiDatabase();
        Stm = Con.createStatement();
        String selectedKode = jComboBox2.getSelectedItem().toString();

        // Query untuk mendapatkan data buku berdasarkan kode
        String sqlBuku = "SELECT * FROM buku WHERE kode = '" + selectedKode + "'";
        ResultSet rsBuku = Stm.executeQuery(sqlBuku);
        if (rsBuku.next()) {
            Kode = rsBuku.getString("kode_kategori");
        }

        // Query untuk mendapatkan tanggal peminjaman berdasarkan kode buku
        String sqlPeminjaman = "SELECT tanggal_peminjaman FROM peminjaman_buku WHERE kode_buku = '" + selectedKode + "'";
        ResultSet rsPeminjaman = Stm.executeQuery(sqlPeminjaman);
        if (rsPeminjaman.next()) {
            tanggalPeminjaman = rsPeminjaman.getDate("tanggal_peminjaman");
        }

        jTextField2.setText(Kode);
        jDateChooser1.setDate(tanggalPeminjaman);
    } catch (SQLException e) {
        System.out.println("koneksi gagal" + e.toString());
    }

    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FromPengembalianBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FromPengembalianBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FromPengembalianBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FromPengembalianBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FromPengembalianBuku().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
