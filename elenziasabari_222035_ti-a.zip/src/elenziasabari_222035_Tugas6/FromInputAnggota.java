package elenziasabari_222035_Tugas6;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class FromInputAnggota extends javax.swing.JFrame {

        Koneksi Konek = new Koneksi();
        private Connection Con;
        Statement Stm;
        ResultSet Rs;
        String Sql; 
        DefaultTableModel Dtm;
        
    public FromInputAnggota() {
        initComponents();
        KosongkanObjek();
        LoadDataNomor();
        TampilAnggotaPadaTabel();

    }
        private void LoadDataNomor(){
        String kd="";
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from biodata_mahasiswa";
            Rs=Stm.executeQuery(Sql);
                    while(Rs.next()) {
                    jComboBox1.addItem(Rs.getString("nim"));
                    }
                } catch(SQLException e){
                System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
    
    
    
    private void AturJTable(JTable Lihat, int Lebar[]){
    try{
        Lihat.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int banyak = Lihat.getColumnCount();
        for (int i = 0; i < banyak; i++) {
        TableColumn Kolom = Lihat.getColumnModel().getColumn(i);
        Kolom.setPreferredWidth(Lebar[i]);
        Lihat.setRowHeight(20);
        }
            } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "salah"+e);
        }
    }
    private void TampilModelJTabel(){
        try {
            String[]kolom={"Nomor Anggota", "Nama", "Tanggal Masuk"};
            Dtm = new DefaultTableModel(null, kolom){
                @Override
                public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        };
        jTable1.setModel(Dtm);
        AturJTable(jTable1, new int 
       []{100,200,200} );
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "salah"+e);
        }
    }
    
    void TampilAnggotaPadaTabel(){
        try {
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement(); 
        TampilModelJTabel();
            try{
            Sql ="SELECT anggota_perpustakaan.nomor, anggota_perpustakaan.tanggal_masuk AS tanggal_masuk, biodata_mahasiswa.nama " +
            "FROM anggota_perpustakaan " +
            "LEFT OUTER JOIN biodata_mahasiswa ON anggota_perpustakaan.nomor = biodata_mahasiswa.nim";
            
            Rs = Stm.executeQuery(Sql);
                while(Rs.next()){
                Dtm.addRow(new Object[]{
                Rs.getString("nomor"),
                Rs.getString("nama"),    
                Rs.getString("tanggal_masuk"),
            });
            jTable1.setModel(Dtm);    
                }
                }catch(Exception e){
                    System.out.println("Ada Kesalahan " + e.toString());
                    }
                }catch (SQLException e){
                    System.out.println("koneksi gagal " + e.toString());
                    }
        }
    
       void KosongkanObjek(){
         jTextField1.setText("");
         jTextField2.setText("");
         jComboBox2.getItemAt(0);
         jDateChooser1.setDate(null);
         jTextField2.requestFocus();
       }
       
     void CariDataAnggota(){
    try {
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement(); 
        TampilModelJTabel();
            try{

                Sql = "SELECT anggota_perpustakaan.nomor, anggota_perpustakaan.tanggal_masuk AS tanggal_masuk " +
                "FROM anggota_perpustakaan"+
               " where anggota_perpustakaan."+jComboBox2.getSelectedItem()+" LIKE '%"+jTextField2.getText()+"%' ";
                System.out.println(jComboBox2.getSelectedItem()); 
        
            
            Rs = Stm.executeQuery(Sql);
            while(Rs.next()){
            Dtm.addRow(new Object[]{
            Rs.getString("nomor"),
            Rs.getString("tanggal_masuk"),
                });
                jTable1.setModel(Dtm);
               }
                }catch(Exception e){
                System.out.println("Ada Kesalahan " + e.toString());
                }
            }catch (SQLException e){
            System.out.println("koneksi gagal " + e.toString());
            }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jTextField1 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jTextField2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Simpan");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Batal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Exit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel1.setText("Nomor Anggota");

        jLabel2.setText("Tanggal Masuk");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih..." }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jLabel3.setText("Cari");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilihan]", "nomor", "tanggal_masuk" }));

        jTextField2.setText("jTextField2");

        jButton6.setText("Cari");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Refresh");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(28, 28, 28)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton6)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6)
                    .addComponent(jButton7))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton5))
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                 try {
            Con = Konek.getKoneksiDatabase();
            Stm = null; 
//            aaaaaaaaaa
            Sql = "DELETE FROM anggota_perpustakaan WHERE nomor = '" + jTextField1.getText() + "'";

            Stm= Con.createStatement();
            int AdaPerubahanRecord= Stm.executeUpdate(Sql);
            TampilAnggotaPadaTabel();
            if (AdaPerubahanRecord>0){
            JOptionPane.showMessageDialog(this,"Data Berhasil Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            jButton1.setEnabled(true);
            }else
            JOptionPane.showMessageDialog(this,"Data Gagal Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            Stm.close();
            
            KosongkanObjek();
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);

            } catch (SQLException e){
            System.out.println("Koneksi Gagal " +e.toString());
            }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String Tampilan="yyyy-MM-dd";
        SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
        String tanggal_masuk = String.valueOf(Fm.format(jDateChooser1.getDate()));
        try {
        Con = Konek.getKoneksiDatabase();
        Stm = null; 
        String cekSql = "SELECT COUNT(*) FROM anggota_perpustakaan WHERE nomor = '" + jComboBox1.getSelectedItem() + "'";
        Stm = Con.createStatement();
        ResultSet rs = Stm.executeQuery(cekSql);
        rs.next();
        int count = rs.getInt(1);
        if (count > 0) {
            JOptionPane.showMessageDialog(this, "Angota Telah terdaftar dalam database!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
            Sql = "INSERT INTO anggota_perpustakaan (nomor, tanggal_masuk, last_update, userid) VALUES ('"
            + jComboBox1.getSelectedItem() + "','" + tanggal_masuk + "', NOW(), 'ADMIN')";

            
             Stm= Con.createStatement();
             int AdaPenambahanRecord= Stm.executeUpdate(Sql);
             TampilAnggotaPadaTabel();
             if (AdaPenambahanRecord>0)
             JOptionPane.showMessageDialog(this,"Data Berhasil Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             else
             JOptionPane.showMessageDialog(this,"Data Gagal Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             Stm.close();
             KosongkanObjek();
             jComboBox1.setSelectedIndex(0);
             jComboBox2.setSelectedIndex(0);
             } catch (SQLException e){
             System.out.println("Koneksi Gagal " +e.toString());
             } 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
                 String Tampilan="yyyy-MM-dd";
        SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
        String tanggal_masuk = String.valueOf(Fm.format(jDateChooser1.getDate()));
        try {
       Con = Konek.getKoneksiDatabase();
        Stm = null; 
        Sql = "UPDATE anggota_perpustakaan SET nomor = '" + jComboBox1.getSelectedItem() + "', tanggal_masuk = '" + tanggal_masuk + "', last_update = NOW(), userid = 'ADMIN' WHERE nomor = '"
            + jComboBox1.getSelectedItem() + "'";

        Stm= Con.createStatement();
        int AdaPerubahanRecord= Stm.executeUpdate(Sql);
        TampilAnggotaPadaTabel();
        if (AdaPerubahanRecord>0){
        JOptionPane.showMessageDialog(this,"Data Berhasil Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        jButton1.setEnabled(true);
        }else
        JOptionPane.showMessageDialog(this,"Data Gagal Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        Stm.close();
        
        KosongkanObjek();
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);

        } catch (SQLException e){
        System.out.println("Koneksi Gagal " +e.toString());
        } 
    
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        KosongkanObjek();
        jButton1.setEnabled(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
                 this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
                 String Kode="";
            try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from biodata_mahasiswa where nim='" 
           +jComboBox1.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField1.setText(Kode);
                } catch(SQLException e){
            System.out.println("koneksi gagal"+e.toString()); 
                }
//        String selectedValue = jComboBox1.getSelectedItem().toString();
//        jTextField1.setText(selectedValue);
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        CariDataAnggota();
        KosongkanObjek();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        TampilAnggotaPadaTabel();
        KosongkanObjek();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
                try {
        Con = Konek.getKoneksiDatabase();

        Sql = "Select * from anggota_perpustakaan where nomor='" +jComboBox1.getSelectedItem() + 
       "'";
        Stm= Con.createStatement();
        Rs = Stm.executeQuery(Sql);
        if (Rs.next()){
        JOptionPane.showMessageDialog(this,"Nomor Tersebut Sudah Ada Silahkan Input nomor Lain Atau Data Mau Di Edit", "Informasi", 
        JOptionPane.INFORMATION_MESSAGE);

        jButton1.setEnabled(false);
        
        jTextField1.setText(Rs.getString("nomor"));
        jDateChooser1.setDate(Rs.getDate("tanggal_masuk"));

        } else {
        jButton1.setEnabled(true);
        jTextField1.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jTextField1.requestFocus();
        }

        }catch (SQLException e){
        System.out.println("koneksi gagal " + e.toString());
        }
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FromInputAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FromInputAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FromInputAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FromInputAnggota.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FromInputAnggota().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
