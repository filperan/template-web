
package elenziasabari_222035_Tugas6;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class FromInputBuku extends javax.swing.JFrame {
    
        Koneksi Konek = new Koneksi();
        private Connection Con;
        Statement Stm;
        ResultSet Rs;
        String Sql; 
        DefaultTableModel Dtm;
        
    public FromInputBuku() {
        initComponents();
        LoadKategoriBuku();
        LoadTahunTerbit();
        LoadTahunPengadaan();
        KosongkanObjek();
        TampilBukuPadaTabel();

        
    }
    
    private void LoadKategoriBuku(){
    String kd="";
    try{
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement();
        Sql = "select * from kategori_buku";
        Rs=Stm.executeQuery(Sql);
        while(Rs.next()) {
        jComboBox1.addItem(Rs.getString("kode"));
                }
            } catch(SQLException e){
            System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
    private void LoadTahunTerbit(){
        jComboBox2.addItem("2016");
        jComboBox2.addItem("2017");
        jComboBox2.addItem("2018");
        jComboBox2.addItem("2019");
        jComboBox2.addItem("2020");
    }
        private void LoadTahunPengadaan(){
        jComboBox3.addItem("2019");
        jComboBox3.addItem("2020");
        jComboBox3.addItem("2021");
        jComboBox3.addItem("2022");
        jComboBox3.addItem("2023");
    }
    
//        versi baru
    private void AturJTable(JTable Lihat, int Lebar[]) {
        try {
            Lihat.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            int banyak = Lihat.getColumnCount();
            for (int i = 0; i < banyak; i++) {
                if (i < Lebar.length) { // Check array bounds
                    TableColumn Kolom = Lihat.getColumnModel().getColumn(i);
                    Kolom.setPreferredWidth(Lebar[i]);
                }
            }
            Lihat.setRowHeight(20);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "salah" + e);
        }
    }

    private void TampilModelJTabel(){
        try {
            String [] kolom = { "kode", "kategori_buku", "judul", "jumlah", "stock", 
            "pengarang", "penerbit", "tahun_terbit", "tahun_pengadaan", 
            "sumber", "rak", "ISBN", "foto_buku" };
            Dtm = new DefaultTableModel(null, kolom){
                @Override
                public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        };
        jTable1.setModel(Dtm);
        AturJTable(jTable1, new int[] { 70, 100, 100, 100, 100, 100, 100, 100, 100, 100, 70, 70 });
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "salah"+e);
        }
    }
    
        void TampilBukuPadaTabel(){
        try {
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement(); 
            TampilModelJTabel();
                try{
                Sql ="SELECT buku.kode, kategori_buku.nama, buku.judul, buku.jumlah, buku.stock, " +
                "buku.pengarang, buku.penerbit, buku.tahun_terbit, buku.tahun_pengadaan, " +
                "buku.sumber, buku.rak, buku.ISBN, buku.foto_buku " +
                "FROM buku"+
                " LEFT OUTER JOIN kategori_buku ON(buku.kode_kategori=kategori_buku.kode)" ;

                
                Rs = Stm.executeQuery(Sql);
                    while(Rs.next()){
                     Dtm.addRow(new Object[]{
                    Rs.getString("kode"),
                    Rs.getString("nama"),
                    Rs.getString("judul"),
                    Rs.getInt("jumlah"),
                    Rs.getInt("stock"),
                    Rs.getString("pengarang"),
                    Rs.getString("penerbit"),
                    Rs.getInt("tahun_terbit"),
                    Rs.getInt("tahun_pengadaan"),
                    Rs.getString("sumber"),
                    Rs.getString("rak"),
                    Rs.getString("ISBN"),
                    Rs.getString("foto_buku"),

                });
                jTable1.setModel(Dtm);
                
                }
                        }catch(Exception e){
                        System.out.println("Ada Kesalahan " + e.toString());
                        }
                    }catch (SQLException e){
                    System.out.println("koneksi gagal " + e.toString());
                    }
             }
        
        void CariBuku(){
        try {
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement(); 
        TampilModelJTabel();
            try{

                Sql ="SELECT buku.kode, kategori_buku.nama, buku.judul, buku.jumlah, buku.stock, " +
                "buku.pengarang, buku.penerbit, buku.tahun_terbit, buku.tahun_pengadaan, " +
                "buku.sumber, buku.rak, buku.ISBN, buku.foto_buku " +
                "FROM buku"+
                " LEFT OUTER JOIN kategori_buku ON(buku.kode_kategori=kategori_buku.kode)"+
                " where buku."+ jComboBox4.getSelectedItem()+" LIKE '%"+jTextField9.getText()+"%' ";
                System.out.println(jComboBox4.getSelectedItem()); 
        
            
            Rs = Stm.executeQuery(Sql);
            while(Rs.next()){
            Dtm.addRow(new Object[]{
                Rs.getString("kode"),
                Rs.getString("nama"),
                Rs.getString("judul"),
                Rs.getInt("jumlah"),
                Rs.getInt("stock"),
                Rs.getString("pengarang"),
                Rs.getString("penerbit"),
                Rs.getInt("tahun_terbit"),
                Rs.getInt("tahun_pengadaan"),
                Rs.getString("sumber"),
                Rs.getString("rak"),
                Rs.getString("ISBN"),
                Rs.getString("foto_buku"),
                });
                jTable1.setModel(Dtm);
               }
                }catch(Exception e){
                System.out.println("Ada Kesalahan " + e.toString());
                }
            }catch (SQLException e){
            System.out.println("koneksi gagal " + e.toString());
            }
             
         }
        
        void KosongkanObjek(){
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jSpinner1.setValue(0);
        jSpinner2.setValue(0);
        jTextField1.requestFocus();
       }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jTextField5 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox();
        jComboBox3 = new javax.swing.JComboBox();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox();
        jTextField9 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Kode");

        jLabel2.setText("Kategori Buku");

        jLabel3.setText("Judul");

        jLabel4.setText("Jumlah");

        jLabel5.setText("Pengarang");

        jLabel6.setText("Penerbit");

        jLabel7.setText("Tahun Terbit");

        jLabel8.setText("Sumber");

        jLabel9.setText("Nomor Rak");

        jLabel10.setText("ISBN");

        jTextField1.setText("jTextField1");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[pilih]" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextField2.setText("jTextField1");

        jTextField3.setText("jTextField1");

        jTextField4.setText("jTextField1");

        jLabel11.setText("Tahun Pengadaan");

        jLabel12.setText("Stock");

        jTextField5.setText("jTextField1");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[pilih]" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[pilih]" }));

        jTextField6.setText("jTextField1");

        jTextField7.setText("jTextField1");

        jTextField8.setText("jTextField1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jLabel12)
                                                .addGap(18, 18, 18)
                                                .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jTextField4)
                                    .addComponent(jTextField3)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField2))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(57, 57, 57)
                                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(164, 164, 164))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(77, 77, 77)
                                .addComponent(jTextField8))
                            .addComponent(jLabel9)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel8)
                                        .addComponent(jLabel7))
                                    .addGap(30, 30, 30)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jLabel11)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jTextField6)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel11)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jLabel13.setText("Cari");

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]", "kode", "kode_kategori", "" }));

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jButton6.setText("Cari");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Refresh");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton7)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6)
                    .addComponent(jButton7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setText("Simpan");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Batal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Exit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
                 String Kode="";
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from kategori_buku where kode='" 
           +jComboBox1.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField2.setText(Kode);
                } catch(SQLException e){
                System.out.println("koneksi gagal"+e.toString()); 
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
        Con = Konek.getKoneksiDatabase();
        Stm = null; 
        String kode = jTextField1.getText();
        String cekNIMSql = "SELECT COUNT(*) FROM buku WHERE kode = '" + kode + "'";
        Stm = Con.createStatement();
        ResultSet rs = Stm.executeQuery(cekNIMSql);
        rs.next();
        int count = rs.getInt(1);
        if (count > 0) {
            JOptionPane.showMessageDialog(this, "Kode Buku sudah ada dalam database!", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Jika Kode sudah ada, berhenti dan tidak melanjutkan proses INSERT
        }
            Sql = "INSERT INTO buku (id, kode, kode_kategori, judul, jumlah, stock, " + 
            "pengarang, penerbit, tahun_terbit, tahun_pengadaan, sumber, rak, ISBN, " +
            "foto_buku, last_update, userid) VALUES (NULL, '" + jTextField1.getText() + "', '" +
            jComboBox1.getSelectedItem()  + "', '" + jTextField3.getText() + "', " +
            jSpinner1.getValue() + ", " + jSpinner2.getValue() +
            ", '" + jTextField4.getText() + "', '" + jTextField5.getText() + "', '" +
            jComboBox2.getSelectedItem() + "', '" + jComboBox3.getSelectedItem() + "', '" +
            jTextField6.getText() + "', '" + jTextField7.getText() + "', '" +jTextField7.getText()+ "', '" +
            "', NOW(), 'ADMIN')";
            
             Stm= Con.createStatement();
             int AdaPenambahanRecord= Stm.executeUpdate(Sql);
//             TampilDataMhsPadaTabel();
             if (AdaPenambahanRecord>0)
             JOptionPane.showMessageDialog(this,"Data Berhasil Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             else
             JOptionPane.showMessageDialog(this,"Data Gagal Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             Stm.close();
             TampilBukuPadaTabel();
             KosongkanObjek();
             jComboBox1.setSelectedIndex(0);
             jComboBox2.setSelectedIndex(0);
             jComboBox3.setSelectedIndex(0);
             } catch (SQLException e){
             System.out.println("Koneksi Gagal " +e.toString());
             }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
try {
    Con = Konek.getKoneksiDatabase();
    Stm = null;
    Sql = "UPDATE buku SET kode_kategori = '" + jComboBox1.getSelectedItem() + "', " +
          "judul = '" + jTextField3.getText() + "', " +
          "jumlah = " + jSpinner1.getValue() + ", " +
          "stock = " + jSpinner2.getValue() + ", " +
          "pengarang = '" + jTextField4.getText() + "', " +
          "penerbit = '" + jTextField5.getText() + "', " +
          "tahun_terbit = " + jComboBox2.getSelectedItem() + ", " +
          "tahun_pengadaan = " + jComboBox3.getSelectedItem() + ", " +
          "sumber = '" + jTextField6.getText() + "', " +
          "rak = '" + jTextField7.getText() + "', " +
          "ISBN = '" + jTextField8.getText() + "', " +
          "last_update = NOW(), " +
          "userid = 'ADMIN' " +
          "WHERE kode = '" + jTextField1.getText() + "'";

    Stm = Con.createStatement();
    int AdaPerubahanRecord = Stm.executeUpdate(Sql);
    TampilBukuPadaTabel();
    if (AdaPerubahanRecord > 0) {
        JOptionPane.showMessageDialog(this, "Data Berhasil Di Edit",
                "Informasi", JOptionPane.INFORMATION_MESSAGE);
        jButton1.setEnabled(true);
    } else {
        JOptionPane.showMessageDialog(this, "Data Gagal Di Edit",
                "Informasi", JOptionPane.INFORMATION_MESSAGE);
    }
    Stm.close();

    KosongkanObjek();
    jComboBox1.setSelectedIndex(0);
    jComboBox2.setSelectedIndex(0);
} catch (SQLException e) {
    System.out.println("Koneksi Gagal " + e.toString());
}

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
                        try {
        Con = Konek.getKoneksiDatabase();

        Sql = "Select * from buku where kode='" +jTextField1.getText() + 
       "'";
        Stm= Con.createStatement();
        Rs = Stm.executeQuery(Sql);
        if (Rs.next()){
        JOptionPane.showMessageDialog(this,"Nomor Tersebut Sudah Ada Silahkan Input nomor Lain Atau Data Mau Di Edit", "Informasi", 
        JOptionPane.INFORMATION_MESSAGE);

        jButton1.setEnabled(false);
//        taruh sini
        jTextField1.setText(Rs.getString("kode"));
        jTextField2.setText(Rs.getString("kode_kategori"));
        jTextField3.setText(Rs.getString("judul"));
        jSpinner1.setValue(Rs.getInt("jumlah"));
        jSpinner2.setValue(Rs.getInt("stock"));
        jTextField4.setText(Rs.getString("pengarang"));
        jTextField5.setText(Rs.getString("penerbit"));
        jComboBox2.setSelectedItem(Integer.toString(Rs.getInt("tahun_terbit")));
        jComboBox3.setSelectedItem(Integer.toString(Rs.getInt("tahun_pengadaan")));
        jTextField6.setText(Rs.getString("sumber"));
        jTextField7.setText(Rs.getString("rak"));
        jTextField8.setText(Rs.getString("ISBN"));



        } else {
        jButton1.setEnabled(true);
        
        jTextField1.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jTextField1.requestFocus();
        }

        }catch (SQLException e){
        System.out.println("koneksi gagal " + e.toString());
        }
  
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                         try {
            Con = Konek.getKoneksiDatabase();
            Stm = null; 
//            aaaaaaaaaa
            Sql = "DELETE FROM buku WHERE kode = '" + jTextField1.getText() + "'";

            Stm= Con.createStatement();
            int AdaPerubahanRecord= Stm.executeUpdate(Sql);
            TampilBukuPadaTabel();
            if (AdaPerubahanRecord>0){
            JOptionPane.showMessageDialog(this,"Data Berhasil Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            jButton1.setEnabled(true);
            }else
            JOptionPane.showMessageDialog(this,"Data Gagal Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            Stm.close();
            
            KosongkanObjek();
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);

            } catch (SQLException e){
            System.out.println("Koneksi Gagal " +e.toString());
            }
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        KosongkanObjek();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        CariBuku();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        TampilBukuPadaTabel();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FromInputBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FromInputBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FromInputBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FromInputBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FromInputBuku().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
