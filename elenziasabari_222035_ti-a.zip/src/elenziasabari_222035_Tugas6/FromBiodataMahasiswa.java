/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package elenziasabari_222035_Tugas6;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class FromBiodataMahasiswa extends javax.swing.JFrame {

        Koneksi Konek = new Koneksi();
        private Connection Con;
        Statement Stm;
        ResultSet Rs;
        String Sql; 
        DefaultTableModel Dtm;
        
    public FromBiodataMahasiswa() {
        
        initComponents();      
        KosongkanObjek();
        TampilDataMhsPadaTabel();
        LoadDataProdi();
        LoadDataAgama();
        LoadDataKelamin();
        LoadDataProvinsi();
        LoadTahunMasuk();
        
    }
    
    void KosongkanObjek(){
         jTextField1.setText("");
         jTextField2.setText("");
         jTextField3.setText("");
         jTextField4.setText("");
         jTextField5.setText("");
         jTextField6.setText("");
         jTextField7.setText("");
         jTextField8.setText("");
         jTextField9.setText("");
         jTextField10.setText("");
         jTextField11.setText("");
         jTextField12.setText("");
         jTextField13.setText("");
         jTextField14.setText("");
         jTextField15.setText("");
         jTextField16.setText("");
         jTextField17.setText("");
        jTextField1.requestFocus(); 
        }
    
    private void LoadDataAgama(){
        String kd="";
        
        
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from agama";
            Rs=Stm.executeQuery(Sql);
                    while(Rs.next()) {
                    jComboBox2.addItem(Rs.getString("kode"));
                    }
                } catch(SQLException e){
                System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
    
    
    
    private void LoadDataProdi(){
        String kd="";
        
        
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from program_studi";
            Rs=Stm.executeQuery(Sql);
                    while(Rs.next()) {
                    jComboBox1.addItem(Rs.getString("kode_jurusan"));
                    }
                } catch(SQLException e){
                System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
        private void LoadDataProvinsi(){
        String kd="";
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from propinsi";
            Rs=Stm.executeQuery(Sql);
                    while(Rs.next()) {
                    jComboBox3.addItem(Rs.getString("kode"));
                    }
                } catch(SQLException e){
                System.out.println("Koneksi Gagal"+e.toString()); 
        }
    }
    
 
    private void LoadDataKelamin(){
        jComboBox6.addItem("L");
        jComboBox6.addItem("P");
    }
 
    private void LoadTahunMasuk(){
        jComboBox4.addItem("2019");
        jComboBox4.addItem("2020");
        jComboBox4.addItem("2021");
        jComboBox4.addItem("2022");
        jComboBox4.addItem("2023");
    }
 
    private void AturJTable(JTable Lihat, int Lebar[]){
        try{
            Lihat.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                int banyak = Lihat.getColumnCount();
                    for (int i = 0; i < banyak; i++) {
                    TableColumn Kolom = Lihat.getColumnModel().getColumn(i);
                    Kolom.setPreferredWidth(Lebar[i]);
                    Lihat.setRowHeight(20);
                    }
                } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "salah"+e);
    }
    }
    private void TampilModelJTabel(){
        try {
            String[]kolom={"Stambuk","Nama Mahasiswa","Program Studi",
            "Agama","Tempat Lahir","Tgl Lahir","Jenis Kelamin","Alamat","Kota",
            "Provinsi","Kode Pos", "Telepon","Hanphone","Hobi","Wali","Alamat Wali",
            "Telepon Wali","Tahun Masuk"};
            Dtm = new DefaultTableModel(null, kolom){
                @Override
                public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        };
        jTable1.setModel(Dtm);
        AturJTable(jTable1, new int 
       []{100,300,300,90,90,90,90,90,90,90,90,90,90,90,90,90,90,90} );
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "salah"+e);
        }
    }
 
    void TampilDataMhsPadaTabel(){
        try {
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement(); 
            TampilModelJTabel();
                try{

                Sql = "SELECT biodata_mahasiswa.nim ,biodata_mahasiswa.nama AS NamaMahasiswa, "+
               "program_studi.nama AS ProgramStudi, "+
               "agama.nama AS NamaAgama, "+
               "biodata_mahasiswa.tempat_lahir AS TempatLahir, "+
               "biodata_mahasiswa.tanggal_lahir AS TanggalLahir, "+
               "biodata_mahasiswa.jenis_kelamin AS JenisKelamin, "+
               "biodata_mahasiswa.alamat AS Alamat, "+
               "biodata_mahasiswa.kota AS Kota, "+
               "propinsi.nama AS NamaProvinsi, "+
               "biodata_mahasiswa.kode_pos AS KodePos, "+
               "biodata_mahasiswa.telpon AS Telpon, "+
               "biodata_mahasiswa.handphone AS HandPhone, "+
               "biodata_mahasiswa.hobi AS Hobi, "+
               "biodata_mahasiswa.wali AS Wali, "+
               "biodata_mahasiswa.alamat_wali AS AlamatWali, "+
               "biodata_mahasiswa.telpon_wali AS TelponWali, "+
               "biodata_mahasiswa.tahun_masuk AS TahunMasuk "+
               " FROM "+
               " biodata_mahasiswa "+ 
               " LEFT OUTER JOIN program_studi ON(biodata_mahasiswa.kode_program_studi=program_studi.kode_jurusan)"+
               " LEFT OUTER JOIN agama ON(biodata_mahasiswa.kode_agama=agama.kode)"+
               " LEFT OUTER JOIN propinsi ON(biodata_mahasiswa.kode_propinsi=propinsi.kode)" ;
                Rs = Stm.executeQuery(Sql);
                    while(Rs.next()){
                     Dtm.addRow(new Object[]{
                     Rs.getString("nim"),
                     Rs.getString("NamaMahasiswa"),
                     Rs.getString("ProgramStudi"),
                     Rs.getString("NamaAgama"),
                     Rs.getString("TempatLahir"),
                     Rs.getString("TanggalLahir"),
                     Rs.getString("JenisKelamin"),
                     Rs.getString("Alamat"),
                     Rs.getString("Kota"),
                     Rs.getString("NamaProvinsi"),
                     Rs.getString("KodePos"),
                     Rs.getString("Telpon"),
                     Rs.getString("Handphone"),
                     Rs.getString("Hobi"),
                     Rs.getString("Wali"),
                     Rs.getString("AlamatWali"),
                     Rs.getString("TelponWali"),
                     Rs.getString("TahunMasuk"),

                });
                jTable1.setModel(Dtm);
                }
                        }catch(Exception e){
                        System.out.println("Ada Kesalahan " + e.toString());
                        }
                    }catch (SQLException e){
                    System.out.println("koneksi gagal " + e.toString());
                    }
    }
 
    void CariDataMhs(){
    try {
        Con=Konek.getKoneksiDatabase();
        Stm = Con.createStatement(); 
        TampilModelJTabel();
            try{

                Sql = "SELECT biodata_mahasiswa.nim ,biodata_mahasiswa.nama AS NamaMahasiswa, "+
               "program_studi.nama AS ProgramStudi, "+
               "agama.nama AS NamaAgama, "+
               "biodata_mahasiswa.tempat_lahir AS TempatLahir, "+
               "biodata_mahasiswa.tanggal_lahir AS TanggalLahir, "+
               "biodata_mahasiswa.jenis_kelamin AS JenisKelamin, "+
               "biodata_mahasiswa.alamat AS Alamat, "+
               "biodata_mahasiswa.kota AS Kota, "+
               "propinsi.nama AS NamaProvinsi, "+
               "biodata_mahasiswa.kode_pos AS KodePos, "+
               "biodata_mahasiswa.telpon AS Telpon, "+
               "biodata_mahasiswa.handphone AS HandPhone, "+
               "biodata_mahasiswa.hobi AS Hobi, "+
               "biodata_mahasiswa.wali AS Wali, "+
               "biodata_mahasiswa.alamat_wali AS AlamatWali, "+
               "biodata_mahasiswa.telpon_wali AS TelponWali, "+
               "biodata_mahasiswa.tahun_masuk AS TahunMasuk "+
               " FROM "+
               " biodata_mahasiswa "+ 
               " LEFT OUTER JOIN program_studi ON(biodata_mahasiswa.kode_program_studi=program_studi.kode_jurusan)"+
               " LEFT OUTER JOIN agama ON(biodata_mahasiswa.kode_agama=agama.kode)"+
               " LEFT OUTER JOIN propinsi ON(biodata_mahasiswa.kode_propinsi=propinsi.kode) "+
               " where biodata_mahasiswa."+jComboBox5.getSelectedItem()+" LIKE '%"+jTextField17.getText()+"%' ";
                System.out.println(jComboBox5.getSelectedItem());
                
        Rs = Stm.executeQuery(Sql);
            while(Rs.next()){
            Dtm.addRow(new Object[]{
            Rs.getString("nim"),
            Rs.getString("NamaMahasiswa"),
            Rs.getString("ProgramStudi"),
            Rs.getString("NamaAgama"),
            Rs.getString("TempatLahir"),
            Rs.getString("TanggalLahir"),
            Rs.getString("JenisKelamin"),
            Rs.getString("Alamat"),
            Rs.getString("Kota"),
            Rs.getString("NamaProvinsi"),
            Rs.getString("KodePos"),
            Rs.getString("Telpon"),
            Rs.getString("Handphone"),
            Rs.getString("Hobi"),
            Rs.getString("Wali"),
            Rs.getString("AlamatWali"),
            Rs.getString("TelponWali"),
            Rs.getString("TahunMasuk"),

                });
                jTable1.setModel(Dtm);
               }
                }catch(Exception e){
                System.out.println("Ada Kesalahan " + e.toString());
                }
            }catch (SQLException e){
            System.out.println("koneksi gagal " + e.toString());
            }
    }
//    batasss ==============================================================================================
     
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jComboBox1 = new javax.swing.JComboBox();
        jComboBox2 = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox();
        jComboBox4 = new javax.swing.JComboBox();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jComboBox6 = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox();
        jTextField17 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setText("Stambuk");

        jLabel2.setText("Nama");

        jLabel4.setText("Kode Prodi");

        jLabel5.setText("Kode Agama");

        jLabel6.setText("T4 Lahir");

        jLabel7.setText("Tanggal Lahir");

        jLabel8.setText("Jenis Kelamin");

        jLabel9.setText("Alamat");

        jLabel10.setText("Kota");

        jTextField1.setText("jTextField1");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jTextField2.setText("jTextField1");

        jTextField3.setText("jTextField1");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jTextField4.setText("jTextField1");

        jTextField5.setText("jTextField1");

        jTextField6.setText("jTextField1");

        jTextField7.setText("jTextField1");

        jTextField8.setText("jTextField1");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jLabel3.setText("Kode Provinsi");

        jLabel11.setText("Kode Pos");

        jLabel12.setText("Telepon");

        jLabel13.setText("Hanphone");

        jLabel14.setText("Hobi");

        jLabel15.setText("Wali");

        jLabel16.setText("Alamat Wali");

        jLabel17.setText("Telpon Wali");

        jLabel18.setText("Tahun Masuk");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox3ActionPerformed(evt);
            }
        });

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));

        jTextField9.setText("jTextField9");

        jTextField10.setText("jTextField9");

        jTextField11.setText("jTextField9");

        jTextField12.setText("jTextField9");

        jTextField13.setText("jTextField9");

        jTextField14.setText("jTextField9");

        jTextField15.setText("jTextField9");

        jTextField16.setText("jTextField9");

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]" }));
        jComboBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField7)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField6, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE))
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField5)
                    .addComponent(jTextField2)
                    .addComponent(jTextField8)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox2, 0, 95, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField4)
                            .addComponent(jTextField3))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(447, 447, 447))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jTextField11)))
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel14)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel7)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel15)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel9)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel17)
                        .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.getAccessibleContext().setAccessibleParent(jLabel1);

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jLabel19.setText("Cari");

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "[Pilih]", "nim", "nama", "agama", "ProgramStudi", "jenis_kelamin", "kode_propinsi", "tahun_masuk" }));
        jComboBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5ActionPerformed(evt);
            }
        });

        jTextField17.setText("jTextField17");

        jButton6.setText("Cari");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Refresh");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 855, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton6)
                        .addGap(18, 18, 18)
                        .addComponent(jButton7)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6)
                    .addComponent(jButton7))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setText("Simpan");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Batal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Exit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 893, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                // TODO add your handling code here:
        String Tampilan="yyyy-MM-dd";
        SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
        String TanggalLahir = String.valueOf(Fm.format(jDateChooser1.getDate()));
        try {
        Con = Konek.getKoneksiDatabase();
        Stm = null; 
        
        String nim = jTextField1.getText();
        String cekNIMSql = "SELECT COUNT(*) FROM biodata_mahasiswa WHERE nim = '" + nim + "'";
        Stm = Con.createStatement();
        ResultSet rs = Stm.executeQuery(cekNIMSql);
        rs.next();
        int count = rs.getInt(1);
        if (count > 0) {
            JOptionPane.showMessageDialog(this, "NIM sudah ada dalam database!", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Jika NIM sudah ada, berhenti dan tidak melanjutkan proses INSERT
        }
        
            Sql = "insert into biodata_mahasiswa (id, nim, nama, kode_program_studi, kode_agama, tempat_lahir," + 
           "tanggal_lahir, jenis_kelamin, alamat, kota, kode_propinsi, kode_pos, telpon, handphone, hobi, "+
            "wali, alamat_wali, telpon_wali, tahun_masuk, last_update, userid ) VALUES (NULL,'"+jTextField1.getText()+ "', " +
            "'" + jTextField2.getText() + "', '" + jComboBox1.getSelectedItem() + "', '" +jComboBox2.getSelectedItem()+"', '"+jTextField5.getText()+"','"+TanggalLahir+"'," +
            " '"+jComboBox6.getSelectedItem()+"', '"+jTextField7.getText()+"', '"
            +jTextField8.getText()+"', '"+jComboBox3.getSelectedItem()+"', '"
            +jTextField10.getText()+"'," +
            "'"+jTextField11.getText()+"','"+jTextField12.getText()+"','"+jTextField13.getText()
            +"','"+jTextField14.getText()+"','"+jTextField15.getText()+"', " +
            "'"+jTextField16.getText()+"','"+jComboBox4.getSelectedItem()+"',NOW(),'ADMIN')"; 
             Stm= Con.createStatement();
             int AdaPenambahanRecord= Stm.executeUpdate(Sql);
             TampilDataMhsPadaTabel();
             if (AdaPenambahanRecord>0)
             JOptionPane.showMessageDialog(this,"Data Berhasil Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             else
             JOptionPane.showMessageDialog(this,"Data Gagal Tersimpan", 
            "Informasi",JOptionPane.INFORMATION_MESSAGE);
             Stm.close();
             KosongkanObjek();
             jComboBox1.setSelectedIndex(0);
             jComboBox2.setSelectedIndex(0);
             jComboBox3.setSelectedIndex(0);
             jComboBox4.setSelectedIndex(0);
             jComboBox6.setSelectedIndex(0);
             } catch (SQLException e){
             System.out.println("Koneksi Gagal " +e.toString());
             } 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
         String Kode="";
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from program_studi where kode_jurusan='"
            +jComboBox1.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField3.setText(Kode);
                } catch(SQLException e){
                System.out.println("koneksi gagal"+e.toString()); 
            }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
         String Kode="";
        try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from agama where kode='" 
           +jComboBox2.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField4.setText(Kode);
                } catch(SQLException e){
                System.out.println("koneksi gagal"+e.toString()); 
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox6ActionPerformed
        // TODO add your handling code here:
         if (jComboBox6.getSelectedItem().equals("L")){
        jTextField6.setText("Laki - Laki");
       }else {
        jTextField6.setText("Perempuan"); 
       }
    }//GEN-LAST:event_jComboBox6ActionPerformed

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
         String Kode="";
            try{
            Con=Konek.getKoneksiDatabase();
            Stm = Con.createStatement();
            Sql = "select * from propinsi where kode='" 
           +jComboBox3.getSelectedItem().toString()+"'"; 
            Rs=Stm.executeQuery(Sql);
                while(Rs.next()) {
                Kode= Rs.getString("nama");
                }
                jTextField9.setText(Kode);
                } catch(SQLException e){
            System.out.println("koneksi gagal"+e.toString()); 
        }
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
//        gunakan pada combobox1 di tugas ke 2
         try {
        Con = Konek.getKoneksiDatabase();

        Sql = "Select * from biodata_mahasiswa where nim='" +jTextField1.getText() + 
       "'";
        Stm= Con.createStatement();
        Rs = Stm.executeQuery(Sql);
        if (Rs.next()){
        JOptionPane.showMessageDialog(this,"Stambuk Tersebut Sudah Ada Silahkan Input STb Lain Atau Data Mau Di Edit", "Informasi", 
        JOptionPane.INFORMATION_MESSAGE);

        jButton1.setEnabled(false);
        
        jTextField2.setText(Rs.getString("nama"));
        jTextField5.setText(Rs.getString("tempat_lahir"));
        jDateChooser1.setDate(Rs.getDate("tanggal_lahir"));
        jComboBox6.setSelectedItem(Rs.getString("jenis_kelamin"));
        jTextField7.setText(Rs.getString("alamat"));
        jTextField8.setText(Rs.getString("kota"));
        jTextField10.setText(Rs.getString("kode_pos"));
        jTextField11.setText(Rs.getString("telpon"));
        jTextField12.setText(Rs.getString("handphone"));
       jTextField13.setText(Rs.getString("hobi"));
        jTextField14.setText(Rs.getString("wali"));
        jTextField15.setText(Rs.getString("alamat_wali"));
        jTextField16.setText(Rs.getString("telpon_wali"));
        jComboBox4.setSelectedItem(Rs.getString("tahun_masuk"));
        jComboBox1.setSelectedItem(Rs.getString("kode_program_studi"));
//        jComboBox2.setSelectedItem(Rs.getString("kode_agama"));
//        jComboBox3.setSelectedItem(Rs.getString("kode_propinsi"));
        } else {
        jButton1.setEnabled(true);
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jTextField9.setText("");
        jTextField10.setText("");
        jTextField11.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        jTextField14.setText("");
        jTextField15.setText("");
        jTextField16.setText("");
        jTextField17.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox6.setSelectedIndex(0);
        jTextField2.requestFocus();
        }

        }catch (SQLException e){
        System.out.println("koneksi gagal " + e.toString());
        }
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         String Tampilan="yyyy-MM-dd";
        SimpleDateFormat Fm = new SimpleDateFormat(Tampilan);
        String TanggalLahir = String.valueOf(Fm.format(jDateChooser1.getDate()));
        try {
       Con = Konek.getKoneksiDatabase();
        Stm = null; 
        Sql = "update biodata_mahasiswa set nama = '"+jTextField2.getText()+"', kode_program_studi ='"
            +jComboBox1.getSelectedItem()+"' , kode_agama = '"
            +jComboBox2.getSelectedItem()+"', tempat_lahir = '"+jTextField5.getText()+"'," 
            + "tanggal_lahir= '"+TanggalLahir+"', jenis_kelamin = '"
            +jComboBox6.getSelectedItem()+"', alamat = '"+jTextField7.getText()+"', kota='"
            +jTextField8.getText()+"', kode_propinsi = '"
            +jComboBox3.getSelectedItem()+"', kode_pos = '"
            +jTextField10.getText()+"', telpon = '"
            +jTextField11.getText()+"', handphone = '"+jTextField12.getText()+"', hobi = '"
            +jTextField13.getText()+"'," +" wali = '"+jTextField14.getText()
            +"', alamat_wali = '"+jTextField15.getText()+"', telpon_wali='"
            +jTextField16.getText()+"' , tahun_masuk='"
            +jComboBox4.getSelectedItem()+"', last_update= NOW(), userid='ADMIN' where nim = '"
            +jTextField1.getText()+"' ";
        Stm= Con.createStatement();
        int AdaPerubahanRecord= Stm.executeUpdate(Sql);
        TampilDataMhsPadaTabel();
        if (AdaPerubahanRecord>0){
        JOptionPane.showMessageDialog(this,"Data Berhasil Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        jButton1.setEnabled(true);
        }else
        JOptionPane.showMessageDialog(this,"Data Gagal Di Edit", 
       "Informasi",JOptionPane.INFORMATION_MESSAGE);
        Stm.close();
        KosongkanObjek();
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox6.setSelectedIndex(0);

        } catch (SQLException e){
        System.out.println("Koneksi Gagal " +e.toString());
        } 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         try {
            Con = Konek.getKoneksiDatabase();
            Stm = null; 
            Sql = "delete from biodata_mahasiswa where nim = '"+jTextField1.getText()+"' ";
            Stm= Con.createStatement();
            int AdaPerubahanRecord= Stm.executeUpdate(Sql);
            TampilDataMhsPadaTabel();
            if (AdaPerubahanRecord>0){
            JOptionPane.showMessageDialog(this,"Data Berhasil Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            jButton1.setEnabled(true);
            }else
            JOptionPane.showMessageDialog(this,"Data Gagal Di Hapus", 
           "Informasi",JOptionPane.INFORMATION_MESSAGE);
            Stm.close();
            KosongkanObjek();
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
            jComboBox3.setSelectedIndex(0);
            jComboBox4.setSelectedIndex(0);
            jComboBox6.setSelectedIndex(0);

            } catch (SQLException e){
            System.out.println("Koneksi Gagal " +e.toString());
            }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
       KosongkanObjek();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
         CariDataMhs();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
         TampilDataMhsPadaTabel();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
         this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jComboBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
    int baris = jTable1.rowAtPoint(evt.getPoint());
        jTextField1.setText(jTable1.getValueAt(baris, 0).toString());
        jTextField2.setText(jTable1.getValueAt(baris, 1).toString());
        jTextField3.setText(jTable1.getValueAt(baris, 2).toString());
        jTextField4.setText(jTable1.getValueAt(baris, 3).toString());
        jTextField5.setText(jTable1.getValueAt(baris, 4).toString());
        jTextField6.setText(jTable1.getValueAt(baris, 6).toString());
        jTextField7.setText(jTable1.getValueAt(baris, 7).toString());
        jTextField8.setText(jTable1.getValueAt(baris, 8).toString());
        jTextField9.setText(jTable1.getValueAt(baris, 9).toString());
        jTextField10.setText(jTable1.getValueAt(baris, 10).toString());
        jTextField11.setText(jTable1.getValueAt(baris, 11).toString());
        jTextField12.setText(jTable1.getValueAt(baris, 12).toString());
        jTextField13.setText(jTable1.getValueAt(baris, 13).toString());
        jTextField14.setText(jTable1.getValueAt(baris, 14).toString());
        jTextField15.setText(jTable1.getValueAt(baris, 15).toString());
        jTextField16.setText(jTable1.getValueAt(baris, 16).toString());
        jComboBox4.setSelectedItem(jTable1.getValueAt(baris, 17).toString());
        
        String tanggalString = (String) jTable1.getValueAt(baris, 5);
        Date tanggal = null;
        try{
            SimpleDateFormat DateFormat = new SimpleDateFormat("yyyy-MM-dd");
            tanggal = DateFormat.parse(tanggalString);
        } catch (ParseException ex){
            ex.printStackTrace();
        }
        
        if (tanggal != null){
            jDateChooser1.setDate(tanggal);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FromBiodataMahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FromBiodataMahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FromBiodataMahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FromBiodataMahasiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FromBiodataMahasiswa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox2;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JComboBox jComboBox4;
    private javax.swing.JComboBox jComboBox5;
    private javax.swing.JComboBox jComboBox6;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
