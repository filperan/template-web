

package elenziasabari_222035_Tugas6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Koneksi {

private Connection koneksiDatabase;
    public Connection getKoneksiDatabase(){
        if(koneksiDatabase == null){
            try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Ditemukan");
                try {
                koneksiDatabase = 
               DriverManager.getConnection("jdbc:mysql://localhost/perpelen","root", "root");
                System.out.println("Koneksi Database Ditemukan");
                    } catch (SQLException ex) {
                    System.out.println("Koneksi Database Tidak Ditemukan : \nDengan Pesan :" + ex.toString());
                    } 
            } catch (ClassNotFoundException ex) {
            System.out.print("Class Driver Database Tidak Ditemukan : \n Dengan pesan Error " + ex.toString());
            }
        }
        return koneksiDatabase;
 }
}