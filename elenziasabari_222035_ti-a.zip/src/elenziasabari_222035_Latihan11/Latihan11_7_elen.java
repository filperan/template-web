
package elenziasabari_222035_Latihan11;


public class Latihan11_7_elen {
       static void demoproc(){
       try{
           throw new NullPointerException("demo");
       }catch(NullPointerException e){
           System.out.println("Tertangkap didalam demoproc");
           throw e;
       }
       }
    
    public static void main(String[] args) {
        try{
            demoproc();
        }catch(NullPointerException e){
            System.out.println("Menangkap Kembali : " + e);
        }
    }
    
}
