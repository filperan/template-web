/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan11;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
class FinalTryCatch {
    public static void main(String[] args) {
        System.out.println("awal program");
        try{
            System.out.println("Baris ini tidak akan di eksekusi -1.2");
            
            File f = new File ("hello.txt");
            InputStream fis = new FileInputStream(f);
            System.out.println("Baris ini tidak akan di eksekusi - 1.3");
            
        }
        catch (Exception e){
            
        }
        finally{
            System.out.println("Baris di dalam finally akan di eksekusi");
        }
        System.out.println("akhir program");
        // TODO code application logic here
    }
    
}
