/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elenziasabari_222035_Latihan11;


public class FinalTryCatchImpl extends FinalTryCatch {
    
}
