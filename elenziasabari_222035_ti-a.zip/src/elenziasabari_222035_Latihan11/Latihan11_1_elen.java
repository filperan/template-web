package elenziasabari_222035_Latihan11;

import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;

class FileNotFoundExceptionDemo {

    public static void main(String[] args) {
        try {
            File file = new File("E://file.txt");
            FileReader fr = new FileReader(file);
            // Perform operations with FileReader if the file exists
        } catch (FileNotFoundException e) {
            // Handle the FileNotFoundException
            System.err.println("File not found: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
