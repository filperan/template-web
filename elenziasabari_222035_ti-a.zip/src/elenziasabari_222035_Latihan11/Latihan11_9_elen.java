/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan11;

/**
 *
 * @author ASUS
 */
public class Latihan11_9_elen {
    
    
    public static void main(String[] args) {
        String[] arr = {"K", "E", "L", "O", "M", "P", "O", "K", " ", "2"};
        int[] intArr = new int[3];
        
        try{
            System.out.println(11);
            intArr[1] = 4/0;
        }catch(ArrayIndexOutOfBoundsException e){
        System.err.println(e);
        
        }finally{
            System.out.println("from finally");
        }
    }
}