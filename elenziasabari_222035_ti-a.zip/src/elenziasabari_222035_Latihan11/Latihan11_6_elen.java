/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan11;

/**
 *
 * @author ASUS
 */
public class Latihan11_6_elen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            throw new Exception("Kesalahan Terjadi");
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}
