package elenziasabari_222035_Latihan11;


class ContohTryCatch {

    public static void main(String[] args) {
        System.out.println("awal program");
        int x = 10;
        
        x = x/0;
        System.out.println(x);
        System.out.println("akhir program");
    }
    
}
