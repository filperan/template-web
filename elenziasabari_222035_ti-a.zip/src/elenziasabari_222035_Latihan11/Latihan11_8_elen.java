/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan11;

class ArithmeticException extends Exception {
    public ArithmeticException(String message) {
        super(message);
    }
}

public class Latihan11_8_elen {
    void method1() throws ArithmeticException {
        throw new ArithmeticException("Calculate Error");
    }

    void method2() throws ArithmeticException {
        method1();
    }

    void method3() {
        try {
            method2();
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception Handled");
        }
    }

    public static void main(String[] args) {
        Latihan11_8_elen obj = new Latihan11_8_elen();
        obj.method3();
        System.out.println("End Of Program");
    }
}

