/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;

/**
 *
 * @author ASUS
 */
class variabel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a=10;
        int b=a;
        b+=1;
        System.out.println(a+","+b);
        int [] refA ={1};
        int [] refB = refA;
        refB[0]++;
        System.out.println(refA[0]+","+refB[0]);
    }
    
}
