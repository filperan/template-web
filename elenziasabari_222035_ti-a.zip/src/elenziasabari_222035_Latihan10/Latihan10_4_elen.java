/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;

/**
 *
 * @author ASUS
 */
class CobaFinal{

    static String cobaStatic ="COBA STATIC";
    String cobanonStatic ="COBA NON STATIC";
    
    static void cetakS(){
        System.out.println("cobaStatic");
    }
    final void cetakF(){
        System.out.println("cobaStatic");
        System.out.println("cobaNonStatic");
    }
    final static void cetakFS(){
        System.out.println("cobaStatic");
    }
    

}
    

