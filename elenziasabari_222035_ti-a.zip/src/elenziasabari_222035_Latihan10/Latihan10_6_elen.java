/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;

import static java.lang.Math.*;
class StaticImport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(Math.sqrt(4));
        System.out.println(sqrt(4));
        System.out.println(Math.abs(-7));
        System.out.println(Math.round(2.6));
        System.out.println(Math.ceil(2.6));
        System.out.println(Math.floor(2.6));
        System.out.println(Math.min(2,5));
        System.out.println(Math.max(2, 5));
        System.out.println(Math.PI);
        System.out.println(Math.E);
        System.out.println(Math.cos(Math.PI/2));
        System.out.println(Math.sin(Math.PI/2));
        System.out.println(Math.log(10.0));
        System.out.println(Math.pow(2, 4));
        System.out.println(Math.random()*10);
    }
    
}
