/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;

class hewan{
    static int hitung = 0;
    void tambah(){
        hitung++;
    }
    public static void main(String[] args) {
        hewan h1 = new hewan();
        hewan h2 = new hewan();
        System.out.println("nilai sebelum dipanggil oleh h1 :"+ hewan.hitung);
        h1.tambah();;
        System.out.println("nilai sesudah dipanggil oleh h1 :"+ hewan.hitung);
        h2.tambah();
        System.out.println("nilai sesudah dipanggi oleh h2 :"+hewan.hitung);
    }
}
