/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;


class staticInstance {

    public static void main(String[] args) {
        System.out.println(contoh.a);
        contoh c1 = new contoh();
        System.out.println(c1.b);
    }
    
}
class contoh{
    static int a = 10;
    int b = 20;
}
