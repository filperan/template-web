
package elenziasabari_222035_Latihan10;

class Wrapper {

    public static void main(String[] args) {
        //Autoboxing
        int a = 20;
        Integer b = a;
        Integer c = Integer.valueOf(a);
    }
    
}
