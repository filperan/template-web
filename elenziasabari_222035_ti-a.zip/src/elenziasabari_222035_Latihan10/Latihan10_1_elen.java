/*

* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package elenziasabari_222035_Latihan10;

/**
 *
 * @author ASUS
 */
class hitungLuas{
    static double segitiga(double a, double t){
        return a*t/2;
    }
    static double persegi (double s){
        return s*s;
    }
    static double persegiPanjang(double p, double l){
        return p*1;
    }
    static double lingkaran(double r){
        return 3.14*r*r;
    }
}