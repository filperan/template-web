package elenziasabari_222035_Tugas1;

import java.util.Scanner;

public class elenziasabari_222035_WhileIf {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String ulang = "ya";
        
        while (ulang.equalsIgnoreCase("ya")) {
            System.out.print("Masukkan Nama: ");
            String nama = input.nextLine();
            
            System.out.print("Masukkan Nim: ");
            int nim = input.nextInt();
            
            input.nextLine(); // Membersihkan newline di buffer
            
            System.out.print("Masukkan Jurusan: ");
            String jurusan = input.nextLine();
            
            System.out.print("Masukkan Nilai Tugas: ");
            float nilaitugas = input.nextFloat();
            
            System.out.print("Masukkan Nilai Mid: ");
            float nilaimid = input.nextFloat();
            
            System.out.print("Masukkan Nilai Final: ");
            float nilaifinal = input.nextFloat();
            
            double nilaiakhir = (nilaitugas + nilaimid + nilaifinal)/3;
            System.out.println("\nBiodata:");
            System.out.println("Nama: " + nama);
            System.out.println("Nim: " + nim);
            System.out.println("Jurusan: " + jurusan);
            System.out.println("Nilai Tugas: " + nilaitugas);
            System.out.println("Nilai Mid: " + nilaimid);
            System.out.println("Nilai Final: " + nilaifinal);
            System.out.println("Nilai Akhir: " + nilaiakhir);
            
            int grade = (int) nilaiakhir / 10;
            
            switch (grade) {
                case 10:
                case 9:
                    System.out.println("Grade: A");
                    break;
                case 8:
                    System.out.println("Grade: B");
                    break;
                case 7:
                    System.out.println("Grade: C");
                    break;
                case 6:
                    System.out.println("Grade: D");
                    break;
                default:
                    System.out.println("Grade: E");
                    break;
            }
            System.out.print("\nIngin mengisi biodata lagi? (ya/tidak): ");
            input.nextLine();
            ulang = input.nextLine();
        }
    }
}