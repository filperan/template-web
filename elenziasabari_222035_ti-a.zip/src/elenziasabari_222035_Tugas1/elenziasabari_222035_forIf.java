package elenziasabari_222035_Tugas1;

import java.util.Scanner;

public class elenziasabari_222035_forIf {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Masukkan jumlah biodata yang ingin diisi: ");
        int jumlahBiodata = input.nextInt();
        
        for (int i = 1; i <= jumlahBiodata; i++) {
            System.out.println("\nBiodata ke-" + i);
            
            System.out.print("Masukkan nama: ");
            String nama = input.next();
            
            System.out.print("Masukkan Nim: ");
            int nim = input.nextInt();
            
            System.out.print("Masukkan Jurusan): ");
            char jurusan = input.next().charAt(0);
            
            System.out.print("Masukkan Nilai Tugas: ");
            float nilaiTugas = input.nextFloat();
            
            System.out.print("Masukkan Nilai MID: ");
            float nilaiMid = input.nextFloat();
            
            System.out.print("Masukkan Milai Final: ");
            float nilaiFinal = input.nextFloat();
            
            double nilaiAkhir = (nilaiTugas + nilaiMid + nilaiFinal) /3;
            
            System.out.println("\nBiodata:");
            System.out.println("Nama: " + nama);
            System.out.println("Nim: " + nim);
            System.out.println("Jurusan: " + jurusan);
            System.out.println("Nilai Tugas: " + nilaiTugas);
            System.out.println("Nilai MID: " + nilaiMid);
            System.out.println("Nilai final: " + nilaiFinal);
            System.out.println("Nilai Akhir: " + nilaiAkhir);
            
            if (nilaiAkhir >= 80) {
                System.out.println("Grade: A");
            } else if (nilaiAkhir >= 70) {
                System.out.println("Grade: B");
            } else if (nilaiAkhir >= 60) {
                System.out.println("Grade: C");
            } else if (nilaiAkhir >= 50) {
                System.out.println("Grade: D");
            } else {
                System.out.println("Grade: E");
            }
            
        }
    }
    
}
