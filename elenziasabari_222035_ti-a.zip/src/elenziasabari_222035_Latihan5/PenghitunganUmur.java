package elenziasabari_222035_Latihan5;

import java.io.*;
import java.util.*;

public class PenghitunganUmur {
    static final int tahunSekarang = ambiltahun();
    int tahunlahir;
    public int umur;
    
    public PenghitunganUmur(){
    }
    
    public PenghitunganUmur(int tahunlahir){
        this.tahunlahir = tahunlahir;
        umur = tahunSekarang - tahunlahir;
    }
    
    static int ambiltahun(){
        Date tanggal = new Date();
        return tanggal.getYear() + 1900;
    }
    
    int hitungumur (int tahunlahir){
    return tahunSekarang - tahunlahir;
    }
    
    public static void main(String args[]){
     DataInputStream baca = new DataInputStream(System.in);
     int tahunlahir = 0;
     PenghitunganUmur saya;
     
     try{
      System.out.print("Input Tahun Kelahiran Anda : ");
      tahunlahir = Integer.parseInt(baca.readLine());
     }catch(IOException e){}
     
     saya = new PenghitunganUmur(tahunlahir);
     System.out.println("Sekarang tahun : " + PenghitunganUmur.tahunSekarang);
     System.out.println("Anda Sekarang berumur "+ saya.umur + "tahun");
    } 
}
    
