package elenziasabari_222035_Latihan5;

import java.io.*;

public class GolonganUmur {
    static String cekGolongan(int umur){
        String gol="";
        if (umur <20)
            gol = "Anak-anak";
        else
            if(umur <40)
                gol= "Dewasa";
            else
                gol = "Manula";
        return gol;
    }
    
    public GolonganUmur(){
    }
    
    public GolonganUmur (int umur){
        cekGolongan(umur);
    }
    public static void main(String args[]){
        DataInputStream baca = new DataInputStream(System.in);
        int tahunlahir = 0;
        PenghitunganUmur saya;
        
        try{
            System.out.print("Input tahun kelahiran anda :");
            tahunlahir = Integer.parseInt(baca.readLine());
        }catch(IOException e){
            System.out.println("Input gagal!!!");
        }
        saya = new PenghitunganUmur(tahunlahir);
        System.out.println(cekGolongan(saya.umur));
    }
}
