package elenziasabari_222035_Latihan5;

class Lingkaran {
    final static double PI=3.14;
    double jarijari;
    
  Lingkaran(double r){
      jarijari = r;
  }
  
    double getKeliling(){
        double keliling;
        keliling = 2 * jarijari * PI;
        return keliling;
    }
    
    double getLuas(){
        double luas;
        luas = PI * jarijari * jarijari;
        return luas;
    }
}
