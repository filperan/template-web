package elenziasabari_222035_Latihan7;

public class Circle {
    public double x, y, r;

    public Circle(double x, double y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    public Circle(double x, double y) {
        this.x = x;
        this.y = y;
        this.r = 1.0;
    }

    public Circle(double r) {
        this.x = 0.0;
        this.y = 0.0;
        this.r = r;
    }

    public Circle(Circle c) {
        this.x = c.x;
        this.y = c.y;
        this.r = c.r;
    }

    public Circle() {
        this.x = 0.0;
        this.y = 0.0;
        this.r = 1.0;
    }

    public double keliling() {
        return 2 * 3.14159 * r;
    }

    public double luas() {
        return 3.14159 * r * r;
    }

    public static void main(String[] args) {
        Circle c1 = new Circle(2.0, 3.0, 1.5);
        Circle c2 = new Circle(3.0, 4.0);
        Circle c3 = new Circle(2.0);
        Circle c4 = new Circle(c1);
        Circle c5 = new Circle();

        System.out.println("c1 Keliling: " + c1.keliling());
        System.out.println("c1 Luas: " + c1.luas());

        System.out.println("c2 Keliling: " + c2.keliling());
        System.out.println("c2 Luas: " + c2.luas());

        System.out.println("c3 Keliling: " + c3.keliling());
        System.out.println("c3 Luas: " + c3.luas());

        System.out.println("c4 Keliling: " + c4.keliling());
        System.out.println("c4 Luas: " + c4.luas());

        System.out.println("c5 Keliling: " + c5.keliling());
        System.out.println("c5 Luas: " + c5.luas());
    }
}
