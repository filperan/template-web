package elenziasabari_222035_Latihan7;

public class Roaming {
    public void walk() {
        System.out.println("Walking...");
    }
}

class Main {
    public static void main(String[] args) {
        Roaming r = new Roaming();
        r.walk();
    }
}
