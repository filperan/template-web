/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan4;

/**
 *
 * @author ASUS
 */
public class Circle2 {
    public double x, y, r;
    // constructor
    public Circle2(double x, double y, double r)
    {
    this.x = x ;
    this.y = y ;
    this.r = r ;
    }
    // methods
    public double keliling() {
    return 2 * 3.14159 * r ;
    }
    public double luas() {
    return 3.14159 * r * r ;
    }
}

