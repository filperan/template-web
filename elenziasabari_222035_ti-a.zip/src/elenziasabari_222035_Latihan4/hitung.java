/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan4;
import javax.swing.*;
public class hitung {
    public double x,y,r;
    public hitung (double x, double y, double r){
        this.x=x;
        this.y=y;
        this.r=r;
    }
    public double keliling(){
        return 2*3.14*r;}
    public double luas(){
        return 3.14*r*r;
    }
}
class lingkaran{
    public static void main(String[] args){
        hitung c=new hitung(0,0,0);
        String Stra=JOptionPane.showInputDialog("Nilai x= ");
        int d=Integer.parseInt(Stra);
        c.x=2;
        String Strb=JOptionPane.showInputDialog("Nilai y =");
        int e=Integer.parseInt(Stra);
        c.y=e;
        String Strc=JOptionPane.showInputDialog("Nilai r =");
        int f=Integer.parseInt(Stra);
        c.r=f;
        double area =c.luas();
        double kel=c.keliling();
        System.out.println("Luas = "+ area);
        System.out.println("Keliling ="+kel);
    }
}
