/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan4;

/**
 *
 * @author ASUS
 */
public class mhs {
    private String nama;
    private String nim;
    private String ttl;
    private String agama;

public mhs(String nama, String nim, String ttl, String agama){
    this.nama = nama;
    this.nim = nim;
    this.ttl = ttl;
    this.agama = agama;
}
public String getNama() {
    return this.nama; 
}
public String getNim() {
    return nim;
}
public static void main(String args[]) {
    mhs m = new mhs("joko", "192001", "17", 
    "Hindu") ;
    System.out.println("Nama =" + m.getNama());

    }
}
