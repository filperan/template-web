/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elenziasabari_222035_Latihan4;

/**
 *
 * @author ASUS
 */
class Buku {
    String pengarang;
    String judul;
void isi (String isi1,String isi2){
    judul=isi1;
    pengarang = isi2;
}
void cetakkelayar(){
    if(judul==null && pengarang == null) return;
    System.out.println("Judul : "+ pengarang);
}
}

class karangan{
public static void main(String[] args) {
    Buku a,b,c,d;
    a = b = c = d = new Buku();
    a.isi("Pemrograman Java","Asep Herman Suyanto");
    a.cetakkelayar();
    b.isi(null,null);
    b.cetakkelayar();
    c.isi(null,"Johan Prasetyo Hendriyanto");
    c.cetakkelayar();
    d.isi("Pemrograman Web",null);
    d.cetakkelayar();
}
}
